num1=int(input("enter a number:"))
num2=int(input("enter another number:"))
print("Surprise... the sum of numbers you entered is...")
print(num1+num2)
