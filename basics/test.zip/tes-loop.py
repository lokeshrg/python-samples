count = 0
while count<4:
    print(count)
    count += 1

print("Umma")

while count<20:
    if (count%2!=0):
        print(count)
    elif count==16:
        print(count)
        print("else if shiva!")
    else:
        print("oddhu ra baboi")
    count+=1

print("chumma")
