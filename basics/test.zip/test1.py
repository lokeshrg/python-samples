print("test")

name = input("enter your dob:")
print(name)
print(name.upper(), sep="$")
print(name[0])
print(name[-1])

print(name.swapcase())

# working
